/* FitMeal - logic.js
   Hitung BMI dan aturan skor rekomendasi (dipindah dari Python). */
function rupiah(n){return 'Rp '+String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g,'.')}
function bmiOf(kg,cm){const m=cm/100;return kg/(m*m)}
function bmiCat(b){
  if(b<18.5) return {key:'kurang',label:'Berat kurang',cls:'warn'};
  if(b<25) return {key:'normal',label:'Normal',cls:''};
  if(b<30) return {key:'lebih',label:'Berat berlebih',cls:'warn'};
  return {key:'obes',label:'Obesitas',cls:'bad'};
}
function goalFromBmi(b){return b>=25?GOALS[0]:(b<18.5?GOALS[2]:GOALS[1])}
function defaultFilters(profile){
  return {budget:30000,veg:false,allergens:[],customAllergens:[],goal:goalFromBmi(bmiOf(profile.berat,profile.tinggi)),act:ACTS[1]};
}

function recommend(p,f){
  const bmi=bmiOf(p.berat,p.tinggi), cat=bmiCat(bmi).key;
  const ageMax=p.umur<25?1:(p.umur>50?2:0);
  const goalMax=f.goal===GOALS[0]?3:2;
  const actMax=f.act===ACTS[2]?2:(f.act===ACTS[0]?1:0);
  const bmiMax=cat==='kurang'?2:((cat==='lebih'||cat==='obes')?1:0);
  const max=1+ageMax+goalMax+actMax+bmiMax;
  const out=[];
  for(const m of FOODS){
    if(m.harga>f.budget) continue;
    if(f.allergens.some(a=>m.alergen.includes(a))) continue;
    const hay=(m.nama+' '+m.deskripsi+' '+m.alergen.join(' ')+' '+(BAHAN[m.id]||'')).toLowerCase();
    if((f.customAllergens||[]).some(t=>hay.includes(t))) continue;
    if(f.veg && !m.vegetarian) continue;
    let s=1; const why=[`Harganya ${rupiah(m.harga)}, masuk anggaranmu.`];
    if(p.umur<25){
      if(m.serat==='Tinggi'){s+=1;why.push(`Serat tinggi, baik untuk usia ${p.umur} tahun.`)}
    }else if(p.umur>50){
      if(m.lemak==='Rendah'){s+=2;why.push(`Rendah lemak dan ramah jantung di usia ${p.umur} tahun.`)}else{s-=1}
    }
    if(f.goal===GOALS[0]){
      if(m.kalori<=300&&m.serat==='Tinggi'){s+=3;why.push('Rendah kalori (maks 300 kcal) dan berserat tinggi untuk menurunkan berat badan.')}
      else if(m.kalori<=450){s+=1;why.push('Kalorinya terkontrol untuk program diet.')}
    }else if(f.goal===GOALS[1]){
      if(m.cocok_diet){s+=2;why.push('Nutrisinya seimbang untuk kebugaran harian.')}
    }else if(f.goal===GOALS[2]){
      if(m.kalori>=350){s+=2;why.push('Padat energi untuk menemani aktivitas harianmu.')}
    }
    if(f.act===ACTS[2]&&m.kalori>=300){s+=2;why.push('Energinya pas untuk mobilitas yang tinggi.')}
    else if(f.act===ACTS[0]&&m.kalori<=300){s+=1;why.push('Ringan dicerna, cocok untuk aktivitas santai.')}
    if(cat==='kurang'&&m.kalori>=350){s+=2;why.push('Padat energi untuk membantu menaikkan berat badan.')}
    if((cat==='lebih'||cat==='obes')){
      if(m.kalori<=350){s+=1;why.push('Kalori ringan, mendukung berat badan yang lebih ideal.')}
      else if(m.kalori>=550){s-=1}
    }
    const ratio=Math.max(0,Math.min(1,s/max));
    out.push({food:m,score:s,pct:Math.round(55+43*ratio),reasons:why});
  }
  out.sort((a,b)=>b.score-a.score||a.food.harga-b.food.harga);
  return out;
}
