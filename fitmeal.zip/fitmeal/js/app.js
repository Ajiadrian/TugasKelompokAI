/* FitMeal - app.js
   Tampilan dan interaksi: login, data tubuh, home, filter, banner, resep. */
/* ---------- ilustrasi piring (SVG, tanpa gambar eksternal) ---------- */
function seeded(seed){let s=seed%2147483647;if(s<=0)s+=2147483646;return()=>(s=s*16807%2147483647)/2147483647}
function art(m){
  const a=m.art,r=seeded(m.id*97+13);
  let g=`<svg viewBox="0 0 240 160" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Ilustrasi ${m.nama}"><rect width="240" height="160" fill="${a.bg}"/>`;
  g+=`<circle cx="122" cy="88" r="66" fill="#000" opacity=".1"/><circle cx="120" cy="82" r="66" style="fill:var(--plate)"/><circle cx="120" cy="82" r="56" fill="none" stroke="#000" stroke-opacity=".07" stroke-width="2"/>`;
  if(a.bowl){
    g+=`<circle cx="120" cy="82" r="50" fill="${a.bowl}"/><circle cx="120" cy="82" r="50" fill="none" stroke="#000" stroke-opacity=".1" stroke-width="3"/>`;
  }
  if(a.mound){
    for(let i=0;i<30;i++){const ang=r()*6.283,rad=24*Math.sqrt(r());g+=`<ellipse cx="${(98+Math.cos(ang)*rad).toFixed(1)}" cy="${(84+Math.sin(ang)*rad).toFixed(1)}" rx="5.5" ry="3.4" transform="rotate(${Math.round(r()*180)} ${(98+Math.cos(ang)*rad).toFixed(1)} ${(84+Math.sin(ang)*rad).toFixed(1)})" fill="${a.mound}" stroke="#000" stroke-opacity=".08"/>`}
  }
  const cx=a.mound?148:120, cy=a.mound?80:82, rr=a.mound?26:36;
  for(let i=0;i<a.leafN;i++){const ang=r()*6.283,rad=rr*Math.sqrt(r()),x=(cx+Math.cos(ang)*rad).toFixed(1),y=(cy+Math.sin(ang)*rad).toFixed(1);g+=`<ellipse cx="${x}" cy="${y}" rx="11" ry="5" transform="rotate(${Math.round(r()*180)} ${x} ${y})" fill="${a.leaf}" stroke="#000" stroke-opacity=".12"/>`}
  for(let i=0;i<a.n;i++){const ang=r()*6.283,rad=rr*Math.sqrt(r()),x=(cx+Math.cos(ang)*rad).toFixed(1),y=(cy+Math.sin(ang)*rad).toFixed(1),sz=(4+r()*5).toFixed(1);g+=`<circle cx="${x}" cy="${y}" r="${sz}" fill="${a.tops[i%a.tops.length]}" stroke="#000" stroke-opacity=".14"/>`}
  return g+'</svg>';
}

/* ---------- util ---------- */
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const mem={};
function sget(k){try{return localStorage.getItem(k)}catch(e){return mem[k]!==undefined?mem[k]:null}}
function sset(k,v){try{localStorage.setItem(k,v)}catch(e){mem[k]=v}}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const cap=s=>s?s.charAt(0).toUpperCase()+s.slice(1):s;
const fmt1=n=>n.toFixed(1).replace('.',',');
const ICON={
  home:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/></svg>',
  user:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>',
  eye:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
  eyeoff:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.5 6.6C3.7 8.4 2 12 2 12s3.6 7 10 7a10 10 0 0 0 4.4-1"/></svg>'
};
const LOGO='<svg viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="10" fill="#8dd3ad"/><path d="M8 24C8 14 14 8 24 8c0 10-6 16-14 16z" fill="#fff"/><path d="M8 24l7-7" stroke="#8dd3ad" stroke-width="2" stroke-linecap="round"/></svg><span>FitMeal</span>';
function toast(t){const el=$('#toast');el.textContent=t;el.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>el.classList.remove('on'),2600)}

/* ---------- penyimpanan akun (demo, di browser) ---------- */
let db={};
try{db=JSON.parse(sget('ms_users')||'{}')||{}}catch(e){db={}}
const saveDb=()=>sset('ms_users',JSON.stringify(db));
const state={user:null,tab:'home',mode:'login'};
let lastRes=[],sheetOpener=null;
const cur=()=>db[state.user];
const dispName=k=>(db[k]&&db[k].name)||cap(k);
async function hashPw(pw,salt){
  try{
    if(window.crypto&&crypto.subtle){
      const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(salt+':'+pw));
      return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
    }
  }catch(e){}
  let h=5381;const s=salt+':'+pw;for(let i=0;i<s.length;i++){h=((h<<5)+h+s.charCodeAt(i))|0}
  return 'f'+(h>>>0).toString(16);
}
const newSalt=()=>Math.random().toString(36).slice(2,10);

/* ---------- navigasi layar ---------- */
function show(id){
  ['auth','onboard','shell'].forEach(s=>{const el=$('#'+s);el.hidden=s!==id;});
  window.scrollTo(0,0);
}
function ov(html){$('#ov-card').innerHTML=html;$('#overlay').classList.add('on')}
function ovHide(){$('#overlay').classList.remove('on')}
async function celebrate(name,next){
  ov(`<svg class="check" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="26"/><path d="M20 33l8 8 16-17"/></svg><h3>Halo, ${name}!</h3><p>Menyiapkan menu untukmu…</p>`);
  await sleep(1250);ovHide();await sleep(200);next();
}
function afterAuth(key){
  state.user=key;sset('ms_session',key);
  celebrate(dispName(key),()=>{cur().profile?showShell():showOnboard()});
}

/* ---------- AUTH UI ---------- */
function setMode(m){
  state.mode=m;const reg=m==='register';
  $('#seg').dataset.pos=reg?'1':'0';
  $$('#seg button').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.mode===m)));
  $('#confirm-wrap').classList.toggle('open',reg);
  $('#confirm-wrap').inert=!reg;
  $('#strength').hidden=!reg;
  $('#auth-title').textContent=reg?'Buat akun':'Masuk';
  $('#auth-sub').textContent=reg?'Gratis. Cukup username dan password, atau daftar dengan Google atau Facebook.':'Selamat datang kembali. Lanjutkan dengan akunmu.';
  $('#auth-submit span').textContent=reg?'Daftar sekarang':'Masuk';
  $('#switch-text').textContent=reg?'Sudah punya akun?':'Belum punya akun?';
  $('#switch-btn').textContent=reg?'Masuk':'Daftar';
  $('#pw').autocomplete=reg?'new-password':'current-password';
  setMsg('');
}
function setMsg(t){$('#auth-msg').textContent=t}
function shake(){const c=$('#auth-card');c.classList.remove('shake');void c.offsetWidth;c.classList.add('shake')}
function strength(pw){
  let s=0;if(pw.length>=6)s++;if(pw.length>=10)s++;if(/[A-Z]/.test(pw)&&/[a-z]/.test(pw))s++;if(/\d/.test(pw)&&/[^A-Za-z0-9]/.test(pw))s++;
  return pw?Math.max(1,s):0;
}
function initAuth(){
  $('#brand-logo').innerHTML=LOGO;
  const minP=Math.min.apply(null,FOODS.map(f=>f.harga));
  $('#facts').innerHTML=`<div class="fact"><b>${FOODS.length}</b><span>menu siap pilih</span></div><div class="fact"><b>${rupiah(minP)}</b><span>harga termurah</span></div><div class="fact"><b>${ALLERGENS.length}</b><span>filter alergi</span></div>`;
  const spots=[[5,'96px','auto','6%','12%','-1s','10s'],[3,'132px','5%','auto','34%','-3s','12s'],[8,'86px','auto','30%','54%','-5s','9s'],[14,'110px','4%','auto','72%','-2s','11s'],[9,'78px','auto','10%','82%','-6s','13s']];
  const ids=[1,3,8,14,9];
  $('#brand-panel').insertAdjacentHTML('beforeend',spots.map((s,i)=>{
    const f=FOODS.find(x=>x.id===ids[i]);
    return `<div class="float${i>0?' hide-m':''}" aria-hidden="true" style="--s:${s[1]};left:${s[2]};right:${s[3]};top:${s[4]};--d:${s[5]};--t:${s[6]}">${art(f)}</div>`;
  }).join(''));
  $('#eye').innerHTML=ICON.eye;
  $('#eye').addEventListener('click',()=>{
    const p=$('#pw'),show=p.type==='password';p.type=show?'text':'password';$('#pw2').type=p.type;
    $('#eye').innerHTML=show?ICON.eyeoff:ICON.eye;$('#eye').setAttribute('aria-label',show?'Sembunyikan password':'Tampilkan password');
  });
  $$('#seg button').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.mode)));
  $('#switch-btn').addEventListener('click',()=>setMode(state.mode==='login'?'register':'login'));
  $('#pw').addEventListener('input',e=>{$('#strength').dataset.s=strength(e.target.value)});
  $$('[data-social]').forEach(b=>b.addEventListener('click',()=>social(b.dataset.social)));
  $('#auth-form').addEventListener('submit',onAuthSubmit);
}
async function social(provider){
  ov(`<div class="big-spin" aria-hidden="true"></div><h3>Menghubungkan ke ${provider}</h3><p>Mode demo: tidak ada data yang dikirim ke ${provider}.</p>`);
  await sleep(1300);ovHide();
  const key=provider.toLowerCase()+'-demo';
  if(!db[key]){db[key]={provider,name:'Akun '+provider,profile:null,filters:null};saveDb()}
  afterAuth(key);
}
async function onAuthSubmit(e){
  e.preventDefault();
  const u=$('#user').value.trim().toLowerCase(),pw=$('#pw').value,btn=$('#auth-submit');
  const fail=t=>{setMsg(t);shake()};
  if(!/^[a-z0-9_.]{3,20}$/.test(u)) return fail('Username 3 sampai 20 karakter: huruf kecil, angka, titik, atau garis bawah.');
  if(pw.length<6) return fail('Password minimal 6 karakter.');
  if(state.mode==='register'&&pw!==$('#pw2').value) return fail('Ulangi password belum sama dengan password di atas.');
  setMsg('');btn.classList.add('loading');btn.disabled=true;
  try{
    await sleep(550);
    if(state.mode==='login'){
      const rec=db[u];
      if(!rec||rec.provider||await hashPw(pw,rec.salt)!==rec.hash) return fail('Username atau password salah. Periksa lagi atau daftar akun baru.');
      afterAuth(u);
    }else{
      if(db[u]) return fail('Username sudah dipakai. Pilih yang lain, atau masuk jika itu akunmu.');
      const salt=newSalt();
      db[u]={salt,hash:await hashPw(pw,salt),provider:null,profile:null,filters:null};
      saveDb();afterAuth(u);
    }
  }finally{btn.classList.remove('loading');btn.disabled=false}
}

/* ---------- form data tubuh (dipakai onboarding dan profil) ---------- */
const BODY=[
  {k:'umur',label:'Umur',unit:'tahun',min:10,max:90},
  {k:'berat',label:'Berat badan',unit:'kg',min:30,max:200},
  {k:'tinggi',label:'Tinggi badan',unit:'cm',min:120,max:220}
];
function mountBody(form,vals,btnLabel,onSubmit){
  const pre=form.id;
  form.innerHTML=`<div class="metrics">${BODY.map(c=>`
    <div class="metric">
      <label for="${pre}-${c.k}">${c.label}</label>
      <div class="metric-row">
        <button type="button" class="step" data-k="${c.k}" data-d="-1" aria-label="Kurangi ${c.label}">−</button>
        <div class="num"><input type="number" id="${pre}-${c.k}" inputmode="numeric" min="${c.min}" max="${c.max}"><span class="unit">${c.unit}</span></div>
        <button type="button" class="step" data-k="${c.k}" data-d="1" aria-label="Tambah ${c.label}">+</button>
      </div>
      <input type="range" id="${pre}-${c.k}-r" min="${c.min}" max="${c.max}" aria-label="Geser ${c.label}">
    </div>`).join('')}</div>
    <div class="bmi">
      <div class="bmi-top"><div><span class="hint">Indeks massa tubuh (BMI)</span><br><b data-bmi>–</b></div><span class="badge" data-cat></span></div>
      <div class="bar"><span class="z z1" style="flex:4.5"></span><span class="z z2" style="flex:6.5"></span><span class="z z3" style="flex:5"></span><span class="z z4" style="flex:6"></span><i class="marker" data-marker></i></div>
      <div class="bar-labels"><span>Kurang</span><span>Normal</span><span>Berlebih</span><span>Obesitas</span></div>
      <p data-tip></p>
    </div>
    <div class="msg" data-msg role="alert"></div>
    <button class="btn btn-primary btn-block" type="submit"><span>${btnLabel}</span></button>`;
  const num=k=>$('#'+pre+'-'+k),rng=k=>$('#'+pre+'-'+k+'-r');
  const clamp=(c,v)=>Math.min(c.max,Math.max(c.min,Math.round(Number(v))||c.min));
  const read=()=>{const o={};BODY.forEach(c=>{o[c.k]=clamp(c,num(c.k).value)});return o};
  function paint(){
    const v=read(),b=bmiOf(v.berat,v.tinggi),cat=bmiCat(b);
    $('[data-bmi]',form).textContent=fmt1(b);
    const bd=$('[data-cat]',form);bd.textContent=cat.label;bd.className='badge '+cat.cls;
    $('[data-marker]',form).style.left=Math.max(1,Math.min(99,(b-14)/22*100))+'%';
    $('[data-tip]',form).textContent={kurang:'Menu padat energi akan diprioritaskan.',normal:'Menu seimbang akan diprioritaskan.',lebih:'Menu berkalori terkontrol akan diprioritaskan.',obes:'Menu berkalori terkontrol akan diprioritaskan. Untuk saran medis, tanyakan ke tenaga kesehatan.'}[cat.key];
  }
  BODY.forEach(c=>{
    const n=num(c.k),r=rng(c.k);n.value=r.value=vals[c.k];
    r.addEventListener('input',()=>{n.value=r.value;paint()});
    n.addEventListener('input',()=>{if(n.value!==''){r.value=clamp(c,n.value);paint()}});
    n.addEventListener('blur',()=>{n.value=clamp(c,n.value);r.value=n.value;paint()});
  });
  $$('.step',form).forEach(b=>b.addEventListener('click',()=>{
    const c=BODY.find(x=>x.k===b.dataset.k),n=num(c.k);
    n.value=clamp(c,Number(n.value||c.min)+Number(b.dataset.d));rng(c.k).value=n.value;paint();
  }));
  form.onsubmit=e=>{e.preventDefault();onSubmit(read())};
  paint();
}

/* ---------- ONBOARDING ---------- */
function showOnboard(){
  $('#ob-title').textContent='Kenalan dulu, '+dispName(state.user);
  mountBody($('#ob-form'),{umur:22,berat:60,tinggi:165},'Simpan dan lihat menu',vals=>{
    const u=cur();u.profile=vals;u.filters=defaultFilters(vals);saveDb();showShell(true);
  });
  show('onboard');
}

/* ---------- SHELL / HOME ---------- */
function showShell(first){
  const u=cur(),name=dispName(state.user);
  $$('.nav-btn[data-tab]').forEach(b=>{b.innerHTML=(b.dataset.tab==='home'?ICON.home+'<span>Beranda</span>':ICON.user+'<span>Profil</span>')});
  ['#side-logo','#top-logo'].forEach(s=>$(s).innerHTML=LOGO);
  ['#side-avatar','#top-avatar','#pf-avatar'].forEach(s=>$(s).textContent=name.charAt(0).toUpperCase());
  $('#side-name').textContent=name;$('#pf-name').textContent=name;
  const prov=u.provider?('Masuk dengan '+u.provider):'Akun username';
  $('#side-provider').textContent=prov;$('#pf-sub').textContent=prov;
  initHero();initFilters();refreshHome();
  mountBody($('#pf-form'),u.profile,'Simpan perubahan',vals=>{
    u.profile=vals;saveDb();refreshHome();toast('Data tubuh diperbarui');
  });
  show('shell');setTab('home');
  if(first)toast('Data tersimpan. Ini menu yang cocok untukmu.');
}
function setTab(t){
  state.tab=t;
  $('#view-home').hidden=t!=='home';$('#view-profile').hidden=t!=='profile';
  $$('.nav-btn[data-tab]').forEach(b=>{if(b.dataset.tab===t)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')});
  window.scrollTo(0,0);
}
function refreshHome(){
  const u=cur(),p=u.profile,b=bmiOf(p.berat,p.tinggi),c=bmiCat(b);
  $('#hello-title').textContent='Halo, '+dispName(state.user)+'!';
  const chip=$('#bmi-chip');chip.textContent=`BMI ${fmt1(b)} · ${c.label}`;chip.className='badge '+c.cls;
  syncFilters();renderResults();
}

/* filter */
function initFilters(){
  const body=$('#fbody');
  body.innerHTML=`
   <div class="fgroup"><span class="flabel">Anggaran per porsi</span><div class="chips">${BUDGETS.map(b=>`<button type="button" class="chip" data-k="budget" data-v="${b.max}">${b.label}</button>`).join('')}</div>
     <form class="mini" id="budget-form" novalidate><label class="sr" for="budget-own">Nominal anggaran sendiri</label><input type="text" id="budget-own" inputmode="numeric" autocomplete="off" placeholder="Nominal sendiri, mis. 27000"><button class="btn btn-ghost" type="submit">Pakai</button></form>
     <p class="fmsg" id="bmsg"></p></div>
   <div class="fgroup"><span class="flabel">Jenis makanan</span><div class="chips"><button type="button" class="chip" data-k="veg" data-v="0">Campur (semua)</button><button type="button" class="chip" data-k="veg" data-v="1">Vegetarian saja</button></div></div>
   <div class="fgroup"><span class="flabel">Hindari alergi</span><div class="chips">${ALLERGENS.map(a=>`<button type="button" class="chip warn" data-k="allergen" data-v="${a}">${a}</button>`).join('')}</div>
     <form class="mini" id="allergy-form" novalidate><label class="sr" for="allergy-own">Alergi lain</label><input type="text" id="allergy-own" autocomplete="off" placeholder="Alergi lain, mis. udang, jagung"><button class="btn btn-ghost" type="submit">Tambah</button></form>
     <div class="chips" id="custom-all"></div></div>
   <div class="fgroup"><span class="flabel">Tujuan utama</span><div class="stack">${GOALS.map((g,i)=>`<button type="button" class="chip" data-k="goal" data-v="${i}">${g}</button>`).join('')}</div></div>
   <div class="fgroup"><span class="flabel">Aktivitas fisik</span><div class="stack">${ACTS.map((g,i)=>`<button type="button" class="chip" data-k="act" data-v="${i}">${g}</button>`).join('')}</div></div>
   <button type="button" class="btn btn-ghost" id="freset">Atur ulang filter</button>`;
  body.onclick=e=>{
    const b=e.target.closest('button');if(!b)return;
    const u=cur(),f=u.filters;f.customAllergens=f.customAllergens||[];
    if(b.id==='freset'){u.filters=defaultFilters(u.profile)}
    else{
      const k=b.dataset.k,v=b.dataset.v;
      if(k==='rmall')f.customAllergens=f.customAllergens.filter(x=>x!==v);
      else if(k==='budget')f.budget=Number(v);
      else if(k==='veg')f.veg=v==='1';
      else if(k==='allergen')f.allergens=f.allergens.includes(v)?f.allergens.filter(x=>x!==v):f.allergens.concat(v);
      else if(k==='goal')f.goal=GOALS[Number(v)];
      else if(k==='act')f.act=ACTS[Number(v)];
    }
    saveDb();syncFilters();renderResults();
  };
  body.onsubmit=e=>{
    e.preventDefault();
    const f=cur().filters;f.customAllergens=f.customAllergens||[];
    if(e.target.id==='budget-form'){
      const n=Number(($('#budget-own').value||'').replace(/\D/g,''));
      const msg=$('#bmsg');
      if(!n||n<1000||n>9999999){msg.textContent='Masukkan nominal antara Rp 1.000 dan Rp 9.999.999.';msg.classList.add('err');return}
      f.budget=n;
    }else if(e.target.id==='allergy-form'){
      const inp=$('#allergy-own');
      const items=inp.value.split(/[,;\n]/).map(t=>t.toLowerCase().replace(/[^\p{L}\p{N} \-]/gu,'').trim()).filter(t=>t.length>=2&&t.length<=30);
      if(!items.length){inp.focus();return}
      items.forEach(t=>{if(!f.customAllergens.includes(t)&&f.customAllergens.length<12)f.customAllergens.push(t)});
      inp.value='';
    }
    saveDb();syncFilters();renderResults();
  };
  $('#ftoggle').onclick=()=>{const o=$('#filters').classList.toggle('open');$('#ftoggle').setAttribute('aria-expanded',String(o));$('#ftoggle').textContent=o?'Tutup':'Atur'};
}
function syncFilters(){
  const f=cur().filters;
  $$('#fbody .chip').forEach(b=>{
    const k=b.dataset.k,v=b.dataset.v;let on=false;
    if(k==='budget')on=f.budget===Number(v);
    else if(k==='veg')on=f.veg===(v==='1');
    else if(k==='allergen')on=f.allergens.includes(v);
    else if(k==='goal')on=f.goal===GOALS[Number(v)];
    else if(k==='act')on=f.act===ACTS[Number(v)];
    b.setAttribute('aria-pressed',String(on));
  });
  f.customAllergens=f.customAllergens||[];
  const bl=BUDGETS.find(b=>b.max===f.budget);
  const own=$('#budget-own'),bmsg=$('#bmsg');
  own.value=bl?'':String(f.budget).replace(/\B(?=(\d{3})+(?!\d))/g,'.');
  bmsg.classList.remove('err');
  bmsg.textContent=bl?'':'Anggaran sendiri aktif: maksimal '+rupiah(f.budget)+' per porsi.';
  $('#custom-all').innerHTML=f.customAllergens.map(t=>`<button type="button" class="chip warn" aria-pressed="true" aria-label="Hapus alergi ${t}" data-k="rmall" data-v="${t}">${t} ×</button>`).join('');
  const all=f.allergens.concat(f.customAllergens);
  $('#fsummary').textContent=[bl?bl.label:'Maks '+rupiah(f.budget),f.veg?'Vegetarian':'Campur',all.length?('Hindari '+all.join(', ')):'Tanpa pantangan alergi'].join(' · ');
}
function cardHTML(r,i){
  const m=r.food;
  return `<article class="card" data-id="${m.id}" style="--i:${Math.min(i,10)}">
    <div class="art">${art(m)}<img class="foto" src="${FOTO(m.id)}" alt="Foto ${m.nama}" loading="lazy"><div class="pills"><span class="pill gold">${rupiah(m.harga)}</span><span class="pill">${m.kalori} kkal</span></div></div>
    <div class="cbody">
      <div class="ctop"><h3>${m.nama}</h3><span class="match" title="Tingkat kecocokan">${r.pct}%</span></div>
      <div class="meter" role="img" aria-label="Kecocokan ${r.pct} persen"><i style="width:${r.pct}%"></i></div>
      <p class="cdesc">${m.deskripsi}</p>
      <div class="tags"><span class="tag ${m.vegetarian?'veg':''}">${m.vegetarian?'Vegetarian':'Mengandung hewani'}</span><span class="tag">Serat ${m.serat.toLowerCase()}</span><span class="tag">Lemak ${m.lemak.toLowerCase()}</span></div>
      <p class="allergen">${m.alergen.length?'Mengandung: <b>'+m.alergen.join(', ')+'</b>':'Tidak ada alergen umum tercatat'}</p>
      <details><summary>Kenapa cocok untukmu</summary><ul>${r.reasons.map(x=>`<li>${x}</li>`).join('')}</ul></details>
      <button class="btn btn-ghost btn-open" type="button" data-open="${m.id}">Lihat resep &amp; pesan</button>
    </div></article>`;
}
function renderResults(){
  const u=cur(),res=recommend(u.profile,u.filters),box=$('#cards');
  lastRes=res;
  $('#res-title').textContent=res.length?`${res.length} menu cocok`:'Belum ada menu cocok';
  $('#res-sub').textContent=res.length?'Diurutkan dari yang paling pas':'';
  if(!res.length){
    box.innerHTML=`<div class="empty"><h3>Filter terlalu ketat</h3><p>Tidak ada menu yang lolos anggaran, jenis makanan, dan alergi yang kamu pilih. Naikkan batas anggaran atau kurangi pantangan.</p><button class="btn btn-primary" id="empty-reset" type="button">Atur ulang filter</button></div>`;
    $('#empty-reset').onclick=()=>{u.filters=defaultFilters(u.profile);saveDb();syncFilters();renderResults()};
    return;
  }
  box.innerHTML=res.map(cardHTML).join('');
  watchImgs(box);
}
/* foto asli tampil kalau filenya ada; kalau belum, ilustrasi piring tetap dipakai */
function watchImgs(root){
  $$('img.foto,img.bn-img',root).forEach(img=>{
    const ok=()=>{if(img.naturalWidth>0)img.classList.add('ok')};
    if(img.complete)ok();else img.addEventListener('load',ok,{once:true});
  });
}

/* ---------- banner promo geser ---------- */
const SLIDES=[
  {t:'Sarapan hemat',h:'Oatmeal pisang & madu',s:'Mulai Rp 14.000, hangat dan tahan lapar.',id:11,bg:'linear-gradient(120deg,#e3f6ea,#b9e5cd)'},
  {t:'Serat tinggi',h:'Nasi merah & tumis brokoli',s:'Kenyang lama dengan kalori terkontrol.',id:1,bg:'linear-gradient(120deg,#fdeedb,#f8d0a6)'},
  {t:'Protein hemat',h:'Tempe bacem & sup tahu',s:'Sumber protein nabati mulai Rp 16.000.',id:7,bg:'linear-gradient(120deg,#fbe6ef,#efc3d9)'},
  {t:'Segar untuk siang',h:'Smoothie bowl buah',s:'Yogurt, buah, dan granola dalam satu mangkuk.',id:14,bg:'linear-gradient(120deg,#e0f1fb,#b7daef)'}
];
function initHero(){
  const root=$('#hero');if(root.dataset.init)return;root.dataset.init='1';
  root.innerHTML=`<div class="hero-track" id="hero-track">${SLIDES.map((s,i)=>`
    <div class="slide" style="--sb:${s.bg}" role="group" aria-roledescription="slide" aria-label="${i+1} dari ${SLIDES.length}">
      <img class="bn-img" src="gambar/banner${i+1}.jpg" alt="">
      <div class="plate-fb" aria-hidden="true">${art(FOODS.find(f=>f.id===s.id))}</div><div class="shade"></div>
      <div class="copy"><button class="btn" type="button" data-menu>Lihat menu</button></div>
    </div>`).join('')}</div>
    <button class="hero-nav prev" type="button" aria-label="Slide sebelumnya">‹</button>
    <button class="hero-nav next" type="button" aria-label="Slide berikutnya">›</button>
    <div class="dots">${SLIDES.map((s,i)=>`<button type="button" aria-label="Ke slide ${i+1}"></button>`).join('')}</div>`;
  watchImgs(root);
  let idx=0,timer=null,paused=false,x0=null;
  const track=$('#hero-track'),dots=$$('.dots button',root);
  const go=n=>{idx=(n+SLIDES.length)%SLIDES.length;track.style.transform='translateX('+(-idx*100)+'%)';dots.forEach((d,i)=>{if(i===idx)d.setAttribute('aria-current','true');else d.removeAttribute('aria-current')})};
  const calm=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  const start=()=>{clearInterval(timer);if(!calm)timer=setInterval(()=>{if(!paused&&!document.hidden&&root.offsetParent!==null)go(idx+1)},4800)};
  root.addEventListener('click',e=>{
    const b=e.target.closest('button');if(!b)return;
    if(b.classList.contains('prev'))go(idx-1);
    else if(b.classList.contains('next'))go(idx+1);
    else if(b.dataset.menu!==undefined)$('#cards').scrollIntoView({behavior:'smooth',block:'start'});
    else{const i=dots.indexOf(b);if(i>=0)go(i)}
    start();
  });
  root.addEventListener('pointerdown',e=>{x0=e.clientX});
  root.addEventListener('pointerup',e=>{
    if(x0===null)return;const dx=e.clientX-x0;x0=null;
    if(Math.abs(dx)>50){go(idx+(dx<0?1:-1));start()}
  });
  root.addEventListener('pointercancel',()=>{x0=null});
  root.addEventListener('mouseenter',()=>{paused=true});root.addEventListener('mouseleave',()=>{paused=false});
  root.addEventListener('focusin',()=>{paused=true});root.addEventListener('focusout',()=>{paused=false});
  go(0);start();
}

/* ---------- detail resep + pesan online ---------- */
function sheetHTML(r){
  const m=r.food,rs=RESEP[m.id];
  const q=encodeURIComponent(m.nama+' GoFood');
  return `<button class="sheet-close" type="button" aria-label="Tutup" data-close>&times;</button>
  <div class="sheet-scroll">
    <div class="art sheet-art">${art(m)}<img class="foto" src="${FOTO(m.id)}" alt="Foto ${m.nama}"></div>
    <div class="sheet-body">
      <div class="sheet-head">
        <h3 id="sheet-title">${m.nama}</h3>
        <div class="sheet-pills"><span class="pill gold">${rupiah(m.harga)}</span><span class="pill">${m.kalori} kkal</span><span class="pill">${rs.waktu}</span><span class="pill">1 porsi</span></div>
        <p class="cdesc">${m.deskripsi}</p>
        <p class="allergen">${m.alergen.length?'Mengandung: <b>'+m.alergen.join(', ')+'</b>':'Tidak ada alergen umum tercatat'}</p>
      </div>
      <div class="sheet-cols">
        <section><h4>Bahan</h4><ul>${rs.bahan.map(x=>`<li>${x}</li>`).join('')}</ul></section>
        <section><h4>Cara membuat</h4><ol>${rs.langkah.map(x=>`<li><span>${x}</span></li>`).join('')}</ol></section>
      </div>
      <section class="why"><h4>Kenapa cocok untukmu</h4><ul>${r.reasons.map(x=>`<li>${x}</li>`).join('')}</ul></section>
      <p class="order-note">Malas masak? Buka GoFood lalu cari <b>${m.nama}</b> atau menu serupa. Aplikasi ini belum bisa memesan otomatis. Kamu juga bisa <a href="https://www.google.com/search?q=${q}" target="_blank" rel="noopener">cari lewat Google</a>. Cek bahan ke penjual kalau kamu punya alergi.</p>
    </div>
  </div>
  <div class="sheet-foot">
    <a class="btn btn-primary" href="https://gofood.co.id" target="_blank" rel="noopener"><span>Pesan lewat GoFood</span></a>
    <button class="btn btn-ghost" type="button" data-copy="${m.nama}">Salin nama menu</button>
  </div>`;
}
function openSheet(id,opener){
  const r=lastRes.find(x=>x.food.id===id);if(!r)return;
  sheetOpener=opener||null;
  const sh=$('#sheet');sh.innerHTML=sheetHTML(r);watchImgs(sh);
  $('#sheet-wrap').classList.add('on');$('#sheet-wrap').setAttribute('aria-hidden','false');
  $('#app').inert=true;
  try{document.body.style.overflow='hidden'}catch(e){}
  $('.sheet-close',sh).focus();
}
function closeSheet(){
  const w=$('#sheet-wrap');if(!w.classList.contains('on'))return;
  w.classList.remove('on');w.setAttribute('aria-hidden','true');
  $('#app').inert=false;
  try{document.body.style.overflow=''}catch(e){}
  if(sheetOpener&&document.contains(sheetOpener))sheetOpener.focus();
}
async function copyName(name){
  try{await navigator.clipboard.writeText(name);toast('Nama menu disalin. Tempel di pencarian GoFood.')}
  catch(e){toast('Ketik manual di GoFood: '+name)}
}

/* ---------- logout & boot ---------- */
function logout(){
  sset('ms_session','');state.user=null;
  $('#user').value='';$('#pw').value='';$('#pw2').value='';$('#strength').dataset.s=0;
  setMode('login');show('auth');
}
function boot(){
  initAuth();
  $$('[data-logout]').forEach(b=>b.addEventListener('click',logout));
  document.addEventListener('click',e=>{const b=e.target.closest('.nav-btn[data-tab]');if(b)setTab(b.dataset.tab)});
  $('#cards').addEventListener('click',e=>{
    const card=e.target.closest('.card');if(!card||e.target.closest('details'))return;
    openSheet(Number(card.dataset.id),e.target.closest('.btn-open')||null);
  });
  $('#sheet-wrap').addEventListener('click',e=>{
    if(e.target.id==='sheet-wrap'||e.target.closest('[data-close]'))closeSheet();
    const c=e.target.closest('[data-copy]');if(c)copyName(c.dataset.copy);
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeSheet()});
  const s=sget('ms_session');
  if(s&&db[s]){state.user=s;db[s].profile?showShell():showOnboard()}
  else show('auth');
}
boot();